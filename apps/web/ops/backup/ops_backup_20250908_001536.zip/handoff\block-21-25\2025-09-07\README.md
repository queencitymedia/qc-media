# Blocks 21–25 Recap (Public & SEO)

**Done**
- robots.txt, sitemap.xml, site.webmanifest (+ link in layout if present), favicon.svg.

**Verify**
Run: \.\verify-21-25.ps1\
