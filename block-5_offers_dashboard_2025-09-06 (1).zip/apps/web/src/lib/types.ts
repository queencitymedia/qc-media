
export type Offer = {
  id: number;
  name: string;
  price_usd?: number | null;
};
