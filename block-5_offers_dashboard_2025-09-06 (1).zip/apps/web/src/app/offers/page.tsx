
import OffersDashboard from "@/src/components/offers/OffersDashboard";

export default function Page() {
  return <OffersDashboard />;
}
